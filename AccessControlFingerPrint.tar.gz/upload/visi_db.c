#include <sqlite3.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <malloc.h>

#define FINGER_DB "finger.db"

static int CreateBlobFinger(sqlite3 *db)
{
  const char *zSql = "CREATE TABLE cred_finger(int id, value fimage)";

  return sqlite3_exec(db, zSql, 0, 0, 0);
}

static int RemoveBlobFinger( sqlite3 *db, int id )
{
	char tmpbuf[100] = {'\0'};

	sprintf( tmpbuf, "DELETE from cred_finger where id = %d", id );

	return sqlite3_exec(db, tmpbuf, 0, 0, 0);
}

static int SaveBlobFinger( sqlite3 *db, int id, const unsigned char *fimage, int size )
{
	char tmpbuf[100] = {'\0'};
  	sqlite3_stmt *pStmt;
  	int rc;
  
	sprintf(tmpbuf, "INSERT INTO cred_finger(id, fimage) VALUES(%d, %s)", id, fimage);

	do 
	{
    		rc = sqlite3_prepare(db, tmpbuf, -1, &pStmt, 0);

    		if( rc!=SQLITE_OK )
		{
      			return rc;
    		}

    		sqlite3_bind_int(pStmt, 1, id);
    		sqlite3_bind_blob(pStmt, 2, fimage, size, SQLITE_STATIC);

    		rc = sqlite3_step(pStmt);
    		assert( rc!=SQLITE_ROW );

    		rc = sqlite3_finalize(pStmt);

  	} while( rc==SQLITE_SCHEMA );

  	return rc;
}

static int RetrieveBlobFinger( sqlite3 *db, int id, unsigned char **pImage, int *pSize )
{
	char tmpbuf[100] = {'\0'};

  	sqlite3_stmt *pStmt;
  	int rc;

	sprintf(tmpbuf, "SELECT fimage FROM cred_finger WHERE id = %d", id); 

  	*pImage = 0;
  	*pSize = 0;

 	do 
	{
    		rc = sqlite3_prepare(db, tmpbuf, -1, &pStmt, 0);

    		if( rc!=SQLITE_OK )
		{
      			return rc;
    		}

    		sqlite3_bind_int(pStmt, 1, id);

    		rc = sqlite3_step(pStmt);

    		if( rc==SQLITE_ROW )
		{
      			*pSize = sqlite3_column_bytes(pStmt, 0);
      			*pImage = (unsigned char *)malloc(*pSize);
      			memcpy(*pImage, sqlite3_column_blob(pStmt, 0), *pSize);
    		}

    		rc = sqlite3_finalize(pStmt);

  	} while( rc==SQLITE_SCHEMA );

  	return rc;
}

static void FreeBlobFinger(unsigned char *imageBlob)
{
	if( imageBlob )
		free(imageBlob);
}

int OpenDataBase(sqlite3 *db)
{
  	sqlite3_open(FINGER_DB, &db);

  	if( SQLITE_OK!=sqlite3_errcode(db) )
	{
    		return 1;
	}
	return 0;
}

void CloseDataBase(sqlite3 *db)
{
	if(db)
	{
		sqlite3_close(db);
	}
}
