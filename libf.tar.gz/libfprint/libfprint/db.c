#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sqlite3.h>
#include <time.h>

#include "fp_internal.h"

typedef struct Node 
{
	int id;
        unsigned char *data;
        struct Node *next;
} Node;

void UpdateInMemory(Node *pointer, int id, unsigned char *data)
{
        /* Iterate through the list till we encounter the last node.*/
        while(pointer->next!=NULL)
        {
                pointer = pointer -> next;
        }
        /* Allocate memory for the new node and put data in it.*/
        pointer->next = (Node *)malloc(sizeof(Node));
	pointer->data = (unsigned char *) malloc (2000);
		
        pointer = pointer->next;
        pointer->id = id;
	pointer->data = data;
        pointer->next = NULL;
}

void RetrieveBlob(sqlite3 *db, int id, unsigned char *blobRetrieved)
{
	char sql[100] = {'\0'};
  	const char *zSqlSelect = "select * from credentials";
        sqlite3_stmt *ppStmt;

	zSqlSelect = sql;

	sprintf(sql, "select * from credentials where id = '%d'", id);

  	if( sqlite3_prepare_v2(db, zSqlSelect, -1, &ppStmt, NULL) != SQLITE_OK )
  	{
		printf("RetrieveBlob : db error\n");
      		sqlite3_close(db);
      		exit(1);
  	}

  	while (sqlite3_step(ppStmt) == SQLITE_ROW)
  	{
		int jj;

      		for(jj=0; jj < sqlite3_column_count(ppStmt); jj++)
      		{
          		switch(sqlite3_column_type(ppStmt, jj))
          		{
             			case SQLITE_INTEGER: 
                  			break;
             			case SQLITE_BLOB:    
				{
                  			unsigned char *blobRetreived;
                  			blobRetreived = (unsigned char *) sqlite3_column_blob(ppStmt, jj);
                  			printf("Blob : %s\n", blobRetreived);
                  			break;
				}
             			default: 
                  			break;
          		}
		}
  		sqlite3_finalize(ppStmt);
     	}
}

API_EXPORTED int CheckBlob(sqlite3 *db, sqlite3_stmt *ppStmt, int id, unsigned char *blobRetrieved)
{
	int eid = 0;
        char sql[100] = {'\0'};
        const char *zSqlSelect = "select * from credentials";

        zSqlSelect = sql;

        sprintf(sql, "select * from credentials where id = '%d'", id);

        if( sqlite3_prepare_v2(db, zSqlSelect, -1, &ppStmt, NULL) != SQLITE_OK )
        {
                printf("RetrieveBlob : db error\n");
                sqlite3_close(db);
                exit(1);
        }

        while (sqlite3_step(ppStmt) == SQLITE_ROW)
        {
                int jj;

                for(jj=0; jj < sqlite3_column_count(ppStmt); jj++)
                {
                        switch(sqlite3_column_type(ppStmt, jj))
                        {
                                case SQLITE_INTEGER:
				{
					eid = (int)sqlite3_column_int(ppStmt, jj); 
                                        break;
				}
                                default:
                                        break;
                        }
                }
                sqlite3_finalize(ppStmt);
        }
	return eid;
}

static int callback(void *None, int argc, char **argv, char **azColName)
{
	return 0;
}

void DeleteBlob(sqlite3 *db, int id)
{
	char *errMsg = 0;
	char sql[100] = {'\0'};

	sprintf(sql, "DELETE from credentials where id=%id", id);

	sqlite3_exec(db, sql, callback, NULL, &errMsg);
}

void InsertBlob(sqlite3 *db, int id, int size, unsigned char *data)
{ 
        sqlite3_stmt *ppStmt;
	int eid = 0;
	const char *cred_sql;
	char sql[100] = {'\0'};

	cred_sql = sql;

        sprintf(sql, "INSERT INTO credentials(id, data) VALUES('%d', ?)", id);

	eid = CheckBlob(db, ppStmt, id, data);

	if( eid == id )
	{
		printf("Record already exist\n");
		exit(1);
	}

	if( sqlite3_prepare_v2(db, cred_sql, -1, &ppStmt, NULL) != SQLITE_OK )
	{
		printf("RetrieveBlob : db error\n");
		sqlite3_close(db);
		exit(1);
	}

	if(ppStmt)
	{
		// For Blob collumn bind 1
		sqlite3_bind_blob(ppStmt, 1, data, size, SQLITE_TRANSIENT);
		sqlite3_step(ppStmt);
		sqlite3_finalize(ppStmt);
		sqlite3_exec(db, "COMMIT", NULL, NULL, NULL);
	}
	else
	{
		printf("Error: ppStmt is NULL\n");
		sqlite3_close(db);
		exit(1);
	}
}

API_EXPORTED void OpenDataBase( sqlite3 **db )
{
        int rc = sqlite3_open("finger.db", db);

        if( rc )
        {
                printf("Can't open database: \n ");
                exit(1);
        }

}

API_EXPORTED void CloseDataBase(sqlite3 *db)
{
	if(db)
	{
  		sqlite3_close(db);
	}
}

API_EXPORTED void AddCredentials(int id, int size, unsigned char *data)
{
        sqlite3 *db;

        OpenDataBase(&db);
 
        InsertBlob(db, id, size, data);

        CloseDataBase(db);
}

API_EXPORTED void DeleteCredentials(int id)
{
        sqlite3 *db;

        OpenDataBase(&db);
 
	DeleteBlob(db, id);

        CloseDataBase(db);
}

API_EXPORTED void FindCredentials(int id, unsigned char *data)
{
        sqlite3 *db;

        OpenDataBase(&db);

	RetrieveBlob(db, id, data);

        CloseDataBase(db);
}
