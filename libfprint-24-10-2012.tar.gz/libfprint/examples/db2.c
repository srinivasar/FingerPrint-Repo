#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sqlite3.h>
#include <time.h>

void RetrieveBlob(sqlite3 *db, int id, unsigned char *blobRetrieved)
{
	char sql[100] = {'\0'};
  	const char *zSqlSelect = "select * from credentials";
        sqlite3_stmt *ppStmt;

	zSqlSelect = sql;

	sprintf(sql, "select * from credentials where id = '%d'", id);

  	if( sqlite3_prepare_v2(db, zSqlSelect, -1, &ppStmt, NULL) != SQLITE_OK )
  	{
		printf("RetrieveBlob : db error\n");
      		sqlite3_close(db);
      		exit(1);
  	}

  	while (sqlite3_step(ppStmt) == SQLITE_ROW)
  	{
		int jj;

      		for(jj=0; jj < sqlite3_column_count(ppStmt); jj++)
      		{
          		switch(sqlite3_column_type(ppStmt, jj))
          		{
             			case SQLITE_INTEGER: 
                  			break;
             			case SQLITE_BLOB:    
				{
                  			unsigned char *blobRetreived;
                  			blobRetreived = (unsigned char *) sqlite3_column_blob(ppStmt, jj);
                  			printf("Blob : %s\n", blobRetreived);
                  			break;
				}
             			default: 
                  			break;
          		}
		}
  		sqlite3_finalize(ppStmt);
     	}
}

int CheckBlob(sqlite3 *db, sqlite3_stmt *ppStmt, int id, unsigned char *blobRetrieved)
{
	int eid = 0;
        char sql[100] = {'\0'};
        const char *zSqlSelect = "select * from credentials";

        zSqlSelect = sql;

        sprintf(sql, "select * from credentials where id = '%d'", id);

        if( sqlite3_prepare_v2(db, zSqlSelect, -1, &ppStmt, NULL) != SQLITE_OK )
        {
                printf("RetrieveBlob : db error\n");
                sqlite3_close(db);
                exit(1);
        }

        while (sqlite3_step(ppStmt) == SQLITE_ROW)
        {
                int jj;

                for(jj=0; jj < sqlite3_column_count(ppStmt); jj++)
                {
                        switch(sqlite3_column_type(ppStmt, jj))
                        {
                                case SQLITE_INTEGER:
				{
					eid = (int)sqlite3_column_int(ppStmt, jj); 
                                        break;
				}
                                default:
                                        break;
                        }
                }
                sqlite3_finalize(ppStmt);
        }
	return eid;
}

void DeleteBlob(sqlite3 *db, int id)
{
	char sql[100] = {'\0'};

	sprintf(sql, "DELETE from credentials where id='%id'", id);

	sqlite3_exec(db, sql, NULL, NULL, NULL);
}

void InsertBlob(sqlite3 *db, int id, int size, unsigned char *data)
{ 
        sqlite3_stmt *ppStmt;
	int eid = 0;
	const char *cred_sql;
	char sql[100] = {'\0'};

	cred_sql = sql;

        sprintf(sql, "INSERT INTO credentials(id, data) VALUES('%d', ?)", id);

	eid = CheckBlob(db, ppStmt, id, data);

	if( eid == id )
	{
		printf("Record already exist\n");
		exit(1);
	}

	if( sqlite3_prepare_v2(db, cred_sql, -1, &ppStmt, NULL) != SQLITE_OK )
	{
		printf("RetrieveBlob : db error\n");
		sqlite3_close(db);
		exit(1);
	}

	if(ppStmt)
	{
		// For Blob collumn bind 1
		sqlite3_bind_blob(ppStmt, 1, data, size, SQLITE_TRANSIENT);
		sqlite3_step(ppStmt);
		sqlite3_finalize(ppStmt);
		sqlite3_exec(db, "COMMIT", NULL, NULL, NULL);
	}
	else
	{
		printf("Error: ppStmt is NULL\n");
		sqlite3_close(db);
		exit(1);
	}
}

void OpenDataBase( sqlite3 **db )
{
        int rc = sqlite3_open("finger.db", db);

        if( rc )
        {
                printf("Can't open database: \n ");
                exit(1);
        }

}

void CloseDataBase(sqlite3 *db)
{
	if(db)
	{
  		sqlite3_close(db);
	}
}

extern void AddCredentials(int id, int size, unsigned char *data)
{
        sqlite3 *db;

        OpenDataBase(&db);
 
        InsertBlob(db, id, size, data);

        CloseDataBase(db);
}

void DeleteCredentials(int id)
{
        sqlite3 *db;

        OpenDataBase(&db);
 
	DeleteBlob(db, id);

        CloseDataBase(db);
}

void FindCredentials(int id, unsigned char *data)
{
        sqlite3 *db;

        OpenDataBase(&db);

	RetrieveBlob(db, id, data);

        CloseDataBase(db);
}

#if 0
int main(int argc, char **argv)
{
	unsigned char *data="hello world";
	unsigned char *rdata;
	char buff[100] = {'\0'};
	int id;
	
	rdata = buff;
        printf("Enter the valid ID : ");
        scanf("%d", &id);

	AddCredentials(id, 50, data);

	FindCredentials(12, rdata);
	FindCredentials(14, rdata);
	FindCredentials(1111, rdata);


	DeleteCredentials(12);
}
#endif
